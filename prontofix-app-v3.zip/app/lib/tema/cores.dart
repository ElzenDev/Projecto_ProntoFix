import 'package:flutter/material.dart';

// Cores do style guide (Figma: "Mockups ProntoFix — Pro").
// Ficam todas aqui para não repetirmos códigos de cor pelos ecrãs.
class Cores {
  static const Color fundo = Color(0xFFF2F7FC);
  static const Color branco = Colors.white;
  static const Color texto = Color(0xFF1F2633);
  static const Color cinza = Color(0xFF7D8799);
  static const Color linha = Color(0xFFE4EAF3);

  static const Color azul = Color(0xFF2663F2);
  static const Color azulClaro = Color(0xFFE8EFFF);
  static const Color laranja = Color(0xFFF59C36);
  static const Color laranjaClaro = Color(0xFFFFF2E3);
  static const Color ciano = Color(0xFF21D1EB);
  static const Color cianoClaro = Color(0xFFE3FAFF);
  static const Color verde = Color(0xFF22B573);
  static const Color verdeClaro = Color(0xFFE8FAF0);
  static const Color vermelho = Color(0xFFE5484D);

  // Ecrã de abertura (fundo escuro)
  static const Color azulNoite = Color(0xFF142138);
  static const Color azulNoiteCartao = Color(0xFF1E2D4A);
}
