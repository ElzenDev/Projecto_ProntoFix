// Testes simples (correm com: flutter test)
// Substitui o widget_test.dart criado pelo "flutter create".

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:prontofix/dados/dados_ficticios.dart';
import 'package:prontofix/main.dart';
import 'package:prontofix/modelos/pedido.dart';

// Ecrã do tamanho de um telemóvel (390 x 844, como nos mockups).
void tamanhoTelemovel(WidgetTester tester) {
  tester.view.physicalSize = const Size(1170, 2532);
  tester.view.devicePixelRatio = 3;
  addTearDown(tester.view.reset);
}

void main() {
  testWidgets('o ecrã inicial abre o login', (WidgetTester tester) async {
    tamanhoTelemovel(tester);
    await tester.pumpWidget(const ProntoFixApp());
    expect(find.text('ProntoFix'), findsOneWidget);

    await tester.tap(find.text('Já tenho conta'));
    await tester.pumpAndSettle();
    expect(find.text('Entrar na tua conta'), findsOneWidget);
  });

  testWidgets('o login valida o email', (WidgetTester tester) async {
    tamanhoTelemovel(tester);
    await tester.pumpWidget(const ProntoFixApp());
    await tester.tap(find.text('Já tenho conta'));
    await tester.pumpAndSettle();

    await tester.tap(find.widgetWithText(FilledButton, 'Entrar'));
    await tester.pump();
    expect(find.text('Introduz o email.'), findsOneWidget);
  });

  test('estimativa de preço depende da urgência', () {
    final List<int> agora = estimarPreco(categorias[0], 'Agora');
    final List<int> normal = estimarPreco(categorias[0], 'Normal');
    expect(agora, [35, 50]);
    expect(normal, [25, 40]);
  });

  test('título do pedido é a primeira frase', () {
    final Pedido p = pedidoProximo();
    expect(p.titulo, 'Fuga na cozinha');
    expect(textoDoEstado(p.estado), 'À procura');
  });

  test('total = mão de obra + material', () {
    final Pedido p = pedidoProximo();
    expect(p.total, isNull);
    p.maoDeObra = 32;
    p.material = 10;
    expect(p.total, 42);
  });

  test('pedido passa para JSON e volta (API REST)', () {
    final Pedido original = pedidoProximo();
    original.estado = EstadoPedido.aCaminho;
    final Map<String, dynamic> json = original.toJson();
    expect(json['estado'], 'a_caminho');

    final Pedido lido = Pedido.fromJson(json);
    expect(lido.estado, EstadoPedido.aCaminho);
    expect(lido.categoria.nome, 'Canalização');
  });

  test('só se cancela antes de o prestador sair', () {
    final Pedido p = pedidoProximo();
    expect(p.podeCancelar, isTrue);
    p.estado = EstadoPedido.aCaminho;
    expect(p.podeCancelar, isFalse);
  });

  test('euros em português', () {
    expect(euros(42), '€ 42,00');
  });
}
