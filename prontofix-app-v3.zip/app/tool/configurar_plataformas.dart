// Acrescenta as permissões de que a app precisa ao Android e ao iOS.
//
// Correr DEPOIS de gerar as pastas das plataformas:
//   flutter create . --org pt.iade --project-name prontofix --platforms android,ios
//   dart run tool/configurar_plataformas.dart
//
// Pode correr-se mais do que uma vez: só acrescenta o que ainda falta.

import 'dart:io';

void main() {
  _android();
  _ios();
  stdout.writeln('\nFeito. Agora: flutter pub get && flutter run');
}

void _android() {
  final f = File('android/app/src/main/AndroidManifest.xml');
  if (!f.existsSync()) {
    stdout.writeln('Android: não encontrei ${f.path}. Corre primeiro o flutter create.');
    return;
  }
  var xml = f.readAsStringSync();

  const permissoes = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.ACCESS_COARSE_LOCATION',
    'android.permission.CAMERA',
  ];
  final novas = permissoes
      .where((p) => !xml.contains('"$p"'))
      .map((p) => '\n    <uses-permission android:name="$p" />')
      .join();
  if (novas.isNotEmpty) {
    final abertura = RegExp(r'<manifest[^>]*>').firstMatch(xml);
    if (abertura != null) {
      xml = xml.substring(0, abertura.end) + novas + xml.substring(abertura.end);
    }
  }

  // Android 11+: dizer que intents a app abre (telefone, SMS, browser/mapas).
  if (!xml.contains('android.intent.action.DIAL')) {
    const intents = '''
        <intent>
            <action android:name="android.intent.action.DIAL" />
            <data android:scheme="tel" />
        </intent>
        <intent>
            <action android:name="android.intent.action.SENDTO" />
            <data android:scheme="sms" />
        </intent>
        <intent>
            <action android:name="android.intent.action.VIEW" />
            <data android:scheme="https" />
        </intent>''';
    if (xml.contains('<queries>')) {
      // O modelo do Flutter já traz um bloco <queries>: acrescentamos dentro.
      xml = xml.replaceFirst('<queries>', '<queries>\n$intents');
    } else {
      xml = xml.replaceFirst(
          '</manifest>', '    <queries>\n$intents\n    </queries>\n</manifest>');
    }
  }

  f.writeAsStringSync(xml);
  stdout.writeln('Android: permissões e queries atualizadas.');
}

void _ios() {
  final f = File('ios/Runner/Info.plist');
  if (!f.existsSync()) {
    stdout.writeln('iOS: não encontrei ${f.path} (ignorado).');
    return;
  }
  var plist = f.readAsStringSync();
  const chaves = {
    'NSLocationWhenInUseUsageDescription':
        'O ProntoFix usa a tua localização para encontrar o prestador mais próximo.',
    'NSCameraUsageDescription':
        'A câmara serve para fotografar a avaria e ler o QR Code de chegada.',
    'NSPhotoLibraryUsageDescription':
        'Para escolheres uma fotografia da avaria a partir da galeria.',
  };
  final novas = StringBuffer();
  chaves.forEach((k, v) {
    if (!plist.contains('<key>$k</key>')) {
      novas.writeln('\t<key>$k</key>\n\t<string>$v</string>');
    }
  });
  if (novas.isNotEmpty) {
    final i = plist.lastIndexOf('</dict>');
    plist = plist.substring(0, i) + novas.toString() + plist.substring(i);
    f.writeAsStringSync(plist);
  }
  stdout.writeln('iOS: descrições de permissões atualizadas.');
}
